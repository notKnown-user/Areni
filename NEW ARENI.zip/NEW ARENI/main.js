document.addEventListener('DOMContentLoaded', () => {
    // Render wine cards
    const wineList = document.getElementById('wine-list');
    
    wines.forEach(wine => {
        const wineCard = document.createElement('div');
        wineCard.className = 'wine-card';
        
        wineCard.innerHTML = `
            <img src="${wine.image}" alt="${wine.name}" class="wine-image">
            <div class="wine-info">
                <h3>${wine.type}</h3>
                <div class="wine-details">
                    <p>Grape: ${wine.grape}</p>
                    <p>Vintage: ${wine.vintage}</p>
                    <p>Alcohol: ${wine.alcohol}</p>
                    <p>Serving temperature: ${wine.servingTemp}</p>
                    ${wine.agingPotential ? `<p>Aging potential: ${wine.agingPotential}</p>` : ''}
                </div>
                <p>${wine.description}</p>
            </div>
        `;
        
        wineList.appendChild(wineCard);
    });

    // Handle form submission
    const contactForm = document.querySelector('.contact-form');
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        // Add your form submission logic here
        alert('Thank you for your message! We will contact you soon.');
        contactForm.reset();
    });

    // Smooth scrolling for navigation links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});