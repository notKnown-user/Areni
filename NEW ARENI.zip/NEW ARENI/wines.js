import { wines } from './wines-data.js'; // Убедитесь, что файл данных называется `wines-data.js`

// Функция для генерации HTML-карты для каждого вина
function createWineCard(wine) {
    return `
        <div class="wine-card">
            <img src="${wine.image}" alt="${wine.name}" class="wine-image">
            <div class="wine-info">
                <h3>${wine.name}</h3>
                <p><strong>Type:</strong> ${wine.type}</p>
                <p><strong>Grape:</strong> ${wine.grape}</p>
                <p><strong>Vintage:</strong> ${wine.vintage}</p>
                <p><strong>Alcohol:</strong> ${wine.alcohol}</p>
                <p><strong>Serving Temp:</strong> ${wine.servingTemp}</p>
                <p>${wine.description}</p>
            </div>
        </div>
    `;
}

// Добавление всех вин в раздел "Our Wines"
const wineList = document.getElementById('wine-list');
wineList.innerHTML = wines.map(createWineCard).join('');
